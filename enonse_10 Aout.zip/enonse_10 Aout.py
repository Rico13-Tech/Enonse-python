print("-----------------------------TAB---------------------------------")
while True:
    nonb = int(input("Rantre yon nonb ant 1 ak 10 pou jenere yon tab : "))
    
    if nonb >= 1 and nonb <= 10:
        for i in range(1, 11):
            rezilta = nonb * i
            print(f"{nonb} x {i} = {rezilta}")
    else:
        print("Nonb la dwe ant 1 ak 10 sèlman.")
    print("peze W siw vle kontinye")
    print("peze N pou kanpe pogram nan")
    repons = input("antre chwa ou an : ")
    if repons.upper() != 'W':
        print("Pwogram nan fini.")
        break